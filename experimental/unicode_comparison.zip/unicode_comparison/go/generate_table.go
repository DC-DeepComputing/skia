// Copyright 2023 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

package main

import (
  //"bufio"
  "path/filepath"
  "io/ioutil"
	"flag"
	"fmt"
  "html/template"
	"os"
  "strings"
  "strconv"
)

func check(e error) {
    if e != nil {
        panic(e)
    }
}

type implStruct struct {
    Implementation string
    Memory float64
    Performance float64
    Accuracy float64
    Rows [] localeStruct
}

type localeStruct struct {
    Language string
    Memory float64
    Performance float64
    Accuracy float64
    Count int
}

type WebPage struct {
    Title string
    Heading string
    Rows [] implStruct
}

func (this *localeStruct) Clean() {
    this.Language = ""
    this.Performance = 0
    this.Memory = 0
    this.Accuracy = 0
    this.Count = 0
}

func (this *implStruct) Clean() {
    this.Implementation = ""
    this.Performance = 0
    this.Memory = 0
    this.Accuracy = 0
    this.Rows = nil
}

func (this *implStruct) Add(other localeStruct) {
    this.Performance += other.Performance
    this.Memory += other.Memory
    this.Accuracy += other.Accuracy
    this.Rows = append(this.Rows, other)
    other.Clean();
}

func addImpl(web *WebPage, impl *implStruct) {
    if len(impl.Implementation) > 0 {
        fmt.Printf("impl: %s = %d\n", impl.Implementation, len(impl.Rows))
        web.Rows = append(web.Rows, *impl)
        impl.Clean()
    }
}

func addLocale(impl *implStruct, locale *localeStruct) {
    if len(locale.Language) > 0 {
        fmt.Printf("locale: %s = %d\n", locale.Language, locale.Count)
        impl.Rows = append(impl.Rows, *locale)
        locale.Clean()
    }
}

func walkRecursively(input string, outputFile *os.File, web *WebPage) error {
    var impl implStruct
    var locale localeStruct
    impl.Clean()
    locale.Clean()
    err := filepath.Walk(input,
    func(inputPath string, info os.FileInfo, err error) error {
        if err != nil {
            fmt.Println(err)
            return err
        }

        if info.IsDir() {
            tokens := strings.Split(inputPath, "/")
            if inputPath[0] == '.' {
                // ./datasets/output
            } else if len(tokens) == 3 {
                addLocale(&impl, &locale)
                addImpl(web, &impl)
                impl.Implementation = tokens[2]
            } else if len(tokens) == 4 {
                addLocale(&impl, &locale)
                locale.Language = tokens[3]
            } else {
                fmt.Println("Currently only supported directory structure: <impl>/<locale>");
            }
        } else {
            if len(locale.Language) ==  0 {
                fmt.Printf("Wrong directory structure, skipped): %s\n", inputPath)
                return nil
            }
            // Read file
            fileContent, err := ioutil.ReadFile(inputPath)
            check(err)
            // Parse file
            tokens := strings.Split(string(fileContent), " ")
            if (len(tokens) == 0) {
                fmt.Println("Wrong data format, skipped)")
                return nil
            }
            time, err1 := strconv.ParseFloat(tokens[0], 64)
            if (err1 != nil) {
                fmt.Println("Wrong time format, skipped)")
                return nil
            }
            locale.Performance += time
            locale.Count += 1
        }
        return nil
    })
    addLocale(&impl, &locale)
    addImpl(web, &impl)
    return err
}

func main() {
    var (
        root = flag.String("root", "./datasets", "Folder (inputs for the table expected to be under <Folder>/output/>")
    )
    flag.Parse()
    if *root == "" {
        fmt.Println("Must set --root")
        flag.PrintDefaults()
    }
    // Define the template
    tmpl := `
<!DOCTYPE html>
<html>
<head>
    <title>{{.Title}}</title>
</head>
<body>
    <table>
        <thead>
            <tr><th>Language</th><th>Disk Memory</th><th>Performance</th><th>Accuracy</th></tr>
        </thead>
        <tbody>
        {{ range $impl := .Rows }}
            <tr>
                <td>{{ .Implementation }}</td>
                <td>{{ .Memory }}</td>
                <td>{{ .Performance }}</td>
                <td>{{ .Accuracy }}</td>
            </tr>
            {{ range $locale := $impl.Rows }}
                <tr>
                    <td>&nbsp;&nbsp;&nbsp;&nbsp;{{ .Language }}</td>
                    <td>{{ .Memory }}</td>
                    <td>{{ .Performance }}</td>
                    <td>{{ .Accuracy }}</td>
                </tr>
            {{ end }}
        {{ end }}
        </tbody>
    </table>
</body>
</html>`

    // Define the data to be used in the template
    web := WebPage {
        Title: "Comparison Table (accuracy, performance and disk memory)",
    }
    // Create a new template and parse the template string
    t, err := template.New("webpage").Parse(tmpl)
    check(err)

    // Create index.html
    indexPath := *root + "/index.html"
    file, err := os.Create(indexPath)
    check(err)

    outputPath := *root + "/output"
    err = walkRecursively(outputPath, file, &web)
    check(err)

    for i := 0; i < len(web.Rows); i++ {
        impl := web.Rows[i]
        fmt.Println(impl.Implementation)
    }

    // Execute the template and write the result to stdout
    err = t.Execute(file, web)
    check(err)
    file.Close()
}
